
DROP TABLE IF EXISTS categories;

