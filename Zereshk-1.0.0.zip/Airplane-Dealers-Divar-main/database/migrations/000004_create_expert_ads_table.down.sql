
DROP TABLE IF EXISTS expert_ads;

