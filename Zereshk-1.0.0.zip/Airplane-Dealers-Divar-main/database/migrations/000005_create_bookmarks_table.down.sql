
DROP TABLE IF EXISTS user_bookmark;
DROP TABLE IF EXISTS bookmarks;

