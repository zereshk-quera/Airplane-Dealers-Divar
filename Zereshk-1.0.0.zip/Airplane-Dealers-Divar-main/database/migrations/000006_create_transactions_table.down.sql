
DROP TABLE IF EXISTS transactions;
