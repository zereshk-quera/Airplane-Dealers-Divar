package models

type BookmarksResponse struct {
	UserID uint
	AdsID  uint
}
