ALTER TABLE phone_book_numbers
ADD COLUMN username VARCHAR(255) UNIQUE;