package utils

const SUBSCRIOPTION_PACKAGE_BUY_ID uint = 666
